var pass = 20;
var score = 3